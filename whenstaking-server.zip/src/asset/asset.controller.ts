import { Request, Response, NextFunction, Router } from 'express';
import Controller from '../interfaces/controller.interface';
import RequestWithUser from '../interfaces/requestWithUser.interface';
import authMiddleware from '../middleware/auth.middleware';
import validationMiddleware from '../middleware/validation.middleware';

import CreateAssetDto from './asset.dto';
import CreateTinfoDto from '../Tinfo/tinfo.dto';
import CreateStakesDto from '../stakes/stakes.dto';

import assetModel from './asset.model';
import tinfoModel from '../tinfo/tinfo.model';
import stakesModel from '../stakes/stakes.model';
import * as moment from 'moment';

interface StringMap{ [key: string] : string; }

class AssetController implements Controller {
  public path = '/assets';
  public router = Router();
  private asset = assetModel;
  private tinfo = tinfoModel;
  private stake = stakesModel;

  constructor() {
    this.initializeRoutes();
  }

  private initializeRoutes() {
    this.router.get(this.path, this.getAllAssets);
    this.router.get(`${this.path}/filter`, this.filterAssets);
    this.router.get(`${this.path}/:account`, this.getAssetByAccount);
    this.router
        .all(`${this.path}/*`, authMiddleware)
        // .patch(`${this.path}/:id`, validationMiddleware(CreateAssetDto, true), this.modifycollection)
        // .delete(`${this.path}/:id`, this.deletePost)
        .post(this.path, authMiddleware, validationMiddleware(CreateAssetDto), this.createAsset)
        .post(`${this.path}/tinfo`, authMiddleware, validationMiddleware(CreateTinfoDto), this.createTinfo)
        .post(`${this.path}/stake`, authMiddleware, validationMiddleware(CreateStakesDto), this.createStakes);
  }

  private getAllAssets = async (request: Request, response: Response) => {
    // const account = request.query.account;
    console.log('assets.all');
    // const assets = await this.asset.find({ owner: account })
    //     .populate('collectionData schemaData template tinfo stake');
    // response.send(assets);
  }

  private getAssetByAccount = async (request: Request, response: Response, next: NextFunction) => {

    // const account = request.params.account;
    console.log('assets.by.account');
    // const assets = await this.asset.find({ owner: account })
    //     .populate('collectionData schemaData template tinfo stake');
    //
    // if (assets) {
    //   response.send(assets);
    // } else {
    //   next(new AssetNotFoundException(account));
    // }
      response.send(moment.utc(new Date()).local().format('YYYY-MM-DDTHH:mm:ss'));
  }

  private filterAssets = async (request: Request, response: Response, next: NextFunction) => {
    const query = request.query;
    console.log('assets.filter', query);

    let assets = [];

    const collectionLookup = {
      from: 'collections',
      localField: 'collection_name',
      foreignField: 'collection_name',
      as: "collection_data",
    };

    const templateLookup = {
      from: 'templates',
      localField: 'template_id',
      foreignField: 'template_id',
      as: "template_data",
    };


    if (query.display === 'expired' || query.display === 'lease') {

      const now = moment.utc(new Date()).local().format('YYYY-MM-DDTHH:mm:ss');
      const expiration = query.display === 'expired' ? { $lte: now } : { $gte: now };

      const schemaLookup = {
        from: 'schemas',
        localField: 'schema_name',
        foreignField: 'schema_name',
        as: "schema_data",
      };

      const parentLookup = {
        from: 'assets',
        localField: 'immutable_data.parent',
        foreignField: 'asset_id',
        as: "parent_data",
      }

      const projects = { collection_data: 1, schema_data: 1, template: 1 };
      const collection_unwind = '$schema_data';
      const match = { $and: [
          { 'immutable_data.expiration': expiration },
          { 'owner': { $eq: query.account } },
        ] };

      assets = await this.asset.aggregate([
        { $lookup: collectionLookup },
        { $lookup: schemaLookup },
        { $lookup: templateLookup },
        { $lookup: parentLookup },
        // { $unwind: collection_unwind },
        { $match: match },
        // { $unwind: data_unwind },


        // { $project: projects },
      ]);
      console.log('assets', assets);
    } else if (query.display === 'mixed') {
      // assets = await this.asset.find({ owner: query.account });
      assets = await this.asset.find({ asset_id: '1099636152349' });
    } else if (query.display === 'stakable') {

      const blacklist = query.template_blacklist.split(',');

      const schemaLookup = {
        from: 'schemas',
        localField: 'schema_name',
        foreignField: 'schema_name',
        pipeline: [{
          $lookup: {
            from: 'schemadats',
            localField: 'schema_name',
            foreignField: 'schema_name',
            as: 'schemadats',
          },
        }],
        as: "schema_data",
      };
      //
      const templateLookup = {
        from: 'templates',
        localField: 'template_id',
        foreignField: 'template_id',
        as: 'template_data',
      };
      //
      const matchAccount = {
        $and: [
          { 'owner': { $eq: query.account } },
          { 'collection_name': { $ne: 'whenstakingx' } },
          { 'template_id' : { $nin: blacklist } },
        ],
      };

      const projects = {
        stakable: { $not: [{ $in: ['$template_id', blacklist] }] },
      };

      assets = await this.asset.aggregate([
        { $lookup: collectionLookup },
        { $lookup: templateLookup },
        // { $unwind: schema_unwind },
        { $lookup: schemaLookup },
        { $match: matchAccount },
        // { $match: matchBlacklist },
        // { $unwind: data_unwind },
        // { $project: projects },
      ]);

    }

    response.send(assets);
  }

  private createAsset = async (request: RequestWithUser, response: Response) => {

    try {
      const assetData: CreateAssetDto = request.body;
      console.log('create.asset', assetData);

      let smart_asset_data : StringMap = {};
      Object.keys(assetData.data).forEach((key: string) => {
        const new_key = key.split('.').join('-');
        smart_asset_data[new_key] = assetData.data[key];
      });

      const createdAsset = new this.asset({
        ...assetData,
        data: smart_asset_data,
      });
      const savedAsset = await createdAsset.save();
      response.send(savedAsset);
    } catch (e) {
      console.log('error', e);
      response.send({ message: JSON.stringify(e) });
    }

  }

  private createTinfo = async (request: RequestWithUser, response: Response) => {
    const tinfo = request.body;

    const createdTinfo = new this.tinfo({
      ...tinfo,
    });

    const savedMeta = await createdTinfo.save();
    response.send(savedMeta);
  }

  private createStakes = async (request: RequestWithUser, response: Response) => {
    const   stakes = request.body;

    const createdStakes = new this.stake({
      ...stakes,
    });

    const savedMeta = await createdStakes.save();
    response.send(savedMeta);
  }


}

export default AssetController;
