interface TmplCaps {
  template_id: string;
  value: string[];
}

export default TmplCaps;
