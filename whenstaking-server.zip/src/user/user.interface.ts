interface User {
  _id: string;
  account: string;
  assets: string;
}

export default User;
