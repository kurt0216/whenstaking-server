interface Collection {
  collection_name: string,
  schemas: string[];
  multis: string[];
  base_capacity: string;
}

export default Collection;
