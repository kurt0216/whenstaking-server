interface Schemas {
  _id: string;
  contract: string;
  schema_name: string;
  created_at_time: string;
  created_at_block: string;
}

export default Schemas;
