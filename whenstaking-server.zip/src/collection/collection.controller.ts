import { Request, Response, NextFunction, Router } from 'express';
import Controller from '../interfaces/controller.interface';
import RequestWithUser from '../interfaces/requestWithUser.interface';
import authMiddleware from '../middleware/auth.middleware';
import validationMiddleware from '../middleware/validation.middleware';
import collectionModel from './collection.model';
import collectionMetaModel from '../collectionmeta/collectionmeta.model';
import CreateCollectionDto from './collection.dto';
import CreateCollectionMetaDto from '../collectionmeta/collectionmeta.dto';
import CollectionNotFoundException from '../exceptions/CollectionNotFoundException';

class CollectionController implements Controller {
  public path = '/collections';
  public router = Router();
  private collection = collectionModel;
  private meta = collectionMetaModel;

  constructor() {
    this.initializeRoutes();
  }

  private initializeRoutes() {
    this.router.get(this.path, this.getAllCollections);
    this.router.get(`${this.path}/:name`, this.getCollectionByName);
    this.router
      .all(`${this.path}/*`, authMiddleware)
      // .patch(`${this.path}/:id`, validationMiddleware(CreateCollectionDto, true), this.modifycollection)
      // .delete(`${this.path}/:id`, this.deletePost)
      .post(this.path, authMiddleware, validationMiddleware(CreateCollectionDto), this.createCollection)
      .post(`${this.path}/meta`, authMiddleware, validationMiddleware(CreateCollectionMetaDto), this.createCollectionMeta)
  }

  private getAllCollections = async (request: Request, response: Response) => {
    const collections = await this.collection.find()
      .populate('meta', '-_id -id');
    response.send(collections);
  }

  private getCollectionByName = async (request: Request, response: Response, next: NextFunction) => {
    const name = request.params.name;
    const post = await this.collection.find({ name });
    if (post) {
      response.send(post);
    } else {
      next(new CollectionNotFoundException(name));
    }
  }

  private createCollection = async (request: RequestWithUser, response: Response) => {
    const collectionData: CreateCollectionDto = request.body;
    // console.log('create.collection', collectionData);
    const createdCollection = new this.collection({
      ...collectionData,
    });
    const savedCollection = await createdCollection.save();
    // await savedCollection.populate('author', '-password').execPopulate();
    response.send(savedCollection);
  }

  private createCollectionMeta = async (request: Request, response: Response) => {
    const metaData = request.body;

    const collection = await this.collection.find({ collection_name: metaData.collection_name });
    const createdCollectionMeta = new this.meta({
      ...metaData,
      // collectionId: collection._id,
    });

    const savedMeta = await createdCollectionMeta.save();
    response.send(savedMeta);
  }
}

export default CollectionController;
