interface TokenData {
  token: string;
  expiresIn: number;
}

export default TokenData;
