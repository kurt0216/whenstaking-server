interface State {
  maintenance: boolean;
  admin: string;
  manager: string;
  epoch: string;
  funding: string[];
  collect: string;
  expLvls: string[];
}

export default State;
