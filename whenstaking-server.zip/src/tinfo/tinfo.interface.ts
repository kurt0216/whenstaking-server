interface Tinfo {
  asset_id: string;
  owner: string;
  level: number;
  staked: number;
  epoch: string;
  quantity: string[];
  value: string[];
  tpts: string[];
}

export default Tinfo;
