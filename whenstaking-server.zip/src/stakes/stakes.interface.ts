interface Skakes {
  asset_id: string;
  quantity: string[];
  tpts: string[];
}

export default Skakes;
